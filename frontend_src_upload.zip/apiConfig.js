﻿/* frontend/src/apiConfig.js */
const FALLBACK = "https://neet-predictor-cyqv.onrender.com";
export const getApiBase = () => {
  if (process.env.REACT_APP_API_BASE) return process.env.REACT_APP_API_BASE;
  if (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_API_BASE) {
    return import.meta.env.VITE_API_BASE;
  }
  return FALLBACK;
};


