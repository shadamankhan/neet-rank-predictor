// frontend/src/routes/ProtectedRoute.jsx
import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { getAuth, onAuthStateChanged } from "firebase/auth";

/**
 * ProtectedRoute - shows children only when user is signed in.
 * While checking auth it returns null (you can show a spinner instead).
 * If not signed in it redirects to /login.
 *
 * Usage:
 * <Route path="/admin" element={<ProtectedRoute><AdminPanel /></ProtectedRoute>} />
 */
export default function ProtectedRoute({ children }) {
  const [checking, setChecking] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const auth = getAuth();
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setChecking(false);
    });

    return () => unsub();
  }, []);

  if (checking) {
    // while we check auth state, return a lightweight placeholder
    return <div style={{ padding: 20 }}>Checking authentication…</div>;
  }

  if (!user) {
    // not signed in -> redirect to /login
    return <Navigate to="/login" replace />;
  }

  // signed in -> render protected children
  return children;
}
