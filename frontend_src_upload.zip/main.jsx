﻿// src/components/main.jsx
import React from "react"; 
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Predictor from "./pages/Predictor";
import DevChecklist from "./components/DevChecklist";
import AdminPanel from "./components/AdminPanel";
import ProtectedRoute from "./routes/ProtectedRoute";

// Ensure Firebase initializes before any auth calls
import "./firebase";

createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <Routes>

      {/* Main Predictor */}
      <Route path="/" element={<Predictor />} />
      <Route path="/predict" element={<Predictor />} />
      <Route path="/checklist" element={<DevChecklist />} />
      {/* ⭐ ADMIN PANEL ROUTE ⭐ */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminPanel />
          </ProtectedRoute>
        }
      />

    </Routes>
  </BrowserRouter>
);
