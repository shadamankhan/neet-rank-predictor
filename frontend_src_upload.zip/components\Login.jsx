// frontend/src/components/Login.jsx
import React from "react";
import { getAuth, signInWithPopup, GoogleAuthProvider } from "firebase/auth";

/**
 * Simple Google Sign-In page.
 * You already have Firebase initialized in ../firebase
 */
export default function Login() {
  const handleGoogleSignIn = async () => {
    try {
      const auth = getAuth();
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      // on success, firebase auth state listener in your app will update and redirect
    } catch (err) {
      console.error("Google sign-in failed:", err);
      alert("Sign-in failed. See console for details.");
    }
  };

  return (
    <div style={{ padding: 24, maxWidth: 720, margin: "40px auto", textAlign: "center" }}>
      <h1>Sign in</h1>
      <p>Please sign in with a Google account to continue.</p>

      <div style={{ marginTop: 18 }}>
        <button
          onClick={handleGoogleSignIn}
          style={{
            padding: "10px 16px",
            borderRadius: 8,
            border: "1px solid #ddd",
            background: "#1f6feb",
            color: "#fff",
            cursor: "pointer"
          }}
        >
          Sign in with Google
        </button>
      </div>

      <div style={{ marginTop: 20, color: "#666" }}>
        <small>
          If you already signed in but still see this page, refresh or wait a moment for auth state to propagate.
        </small>
      </div>
    </div>
  );
}
