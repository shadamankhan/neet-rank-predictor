// frontend/src/components/LoginButton.jsx
import React, { useState } from "react";
import { auth } from "../firebase";
import { GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";

/**
 * Simple Google login button. After sign-in you can call `user.getIdToken(true)`
 * to force-refresh claims (useful after server-side setCustomUserClaims).
 */
export default function LoginButton({ onSignedIn }) {
  const [loading, setLoading] = useState(false);

  const handleSignIn = async () => {
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      // notify parent
      if (onSignedIn) onSignedIn(user);
    } catch (err) {
      console.error("Sign-in failed:", err);
      alert("Sign-in failed: " + (err.message || err));
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      if (onSignedIn) onSignedIn(null);
    } catch (err) {
      console.error("Sign-out failed:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <button onClick={handleSignIn} disabled={loading}>
        Sign in with Google
      </button>{" "}
      <button onClick={handleSignOut} disabled={loading}>
        Sign out
      </button>
    </div>
  );
}
