// frontend/src/components/Navbar.jsx
import React from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav style={{
      display: "flex", gap: 12, alignItems: "center",
      padding: "10px 18px", borderBottom: "1px solid #eee", background: "#fff"
    }}>
      <div style={{ fontWeight: 800 }}>NEET Rank Predictor</div>

      <div style={{ display: "flex", gap: 10, marginLeft: 16 }}>
        <Link to="/" style={linkStyle}>Predictor</Link>
        <Link to="/predict" style={linkStyle}>Predict</Link>
        <Link to="/history" style={linkStyle}>My History</Link>
        <Link to="/admin" style={linkStyle}>Admin Panel</Link>
        <Link to="/admin/import" style={linkStyle}>Admin Import</Link>
        <Link to="/checklist" style={linkStyle}>Checklist</Link>
      </div>

      <div style={{ marginLeft: "auto", display: "flex", gap: 10 }}>
        <Link to="/login" style={smallLink}>Sign in</Link>
      </div>
    </nav>
  );
}

const linkStyle = { textDecoration: "none", padding: "6px 10px", borderRadius: 6, color: "#111" };
const smallLink = { textDecoration: "none", padding: "6px 10px", borderRadius: 6, color: "#666", fontSize: 13 };
