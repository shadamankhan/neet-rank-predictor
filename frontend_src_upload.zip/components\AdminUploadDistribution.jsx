// frontend/src/components/AdminUploadDistribution.jsx
import React, { useState } from 'react';

export default function AdminUploadDistribution() {
  const [file, setFile] = useState(null);
  const [year, setYear] = useState('2024');
  const [msg, setMsg] = useState('');

  const handle = async (e) => {
    e.preventDefault();
    if (!file) { setMsg('Choose a file'); return; }
    const fd = new FormData();
    fd.append('file', file);
    fd.append('year', year);

    // include auth token if endpoint is protected
    const headers = {};
    // if you use firebase auth, get token and set Authorization header

    try {
      const res = await fetch('/api/admin/upload-distribution', {
        method: 'POST',
        body: fd,
        headers
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Upload failed');
      setMsg(`Uploaded year ${data.year}, items=${data.items}`);
    } catch (err) {
      setMsg('Upload error: ' + (err.message || err));
    }
  };

  return (
    <form onSubmit={handle}>
      <div>
        <label>Year: </label>
        <input value={year} onChange={e=>setYear(e.target.value)} />
      </div>
      <div>
        <input type="file" accept=".json,.csv,application/json,text/csv" onChange={e=>setFile(e.target.files[0])} />
      </div>
      <div><button type="submit">Upload distribution</button></div>
      <div style={{marginTop:8}}>{msg}</div>
    </form>
  );
}
