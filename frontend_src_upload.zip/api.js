﻿// src/api.js
const BASE = "http://localhost:5000";

export async function predictApi(score, category = "NEET") {
  const res = await fetch(`${BASE}/api/predict`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ score, category })
  });
  if (!res.ok) throw new Error("Predict request failed: " + res.status);
  return res.json();
}

export async function savePredictionApi(idToken, payload) {
  const res = await fetch(`${BASE}/api/savePrediction`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken}`
    },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error("Save failed: " + res.status + " " + txt);
  }
  return res.json();
}

export async function historyApi(idToken) {
  const res = await fetch(`${BASE}/api/history`, {
    method: "GET",
    headers: { Authorization: `Bearer ${idToken}` }
  });
  if (!res.ok) throw new Error("History failed: " + res.status);
  return res.json();
}
