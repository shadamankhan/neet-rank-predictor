// src/components/AdminUpload.jsx
import React, { useState, useContext } from "react";
import { AuthContext } from "../contexts/AuthContext";

export default function AdminUpload() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");
  const { currentUser, getIdToken } = useContext(AuthContext); // assuming you expose getIdToken
  // If AuthContext doesn't provide token helper, use currentUser.getIdToken()

  const handleFile = (e) => setFile(e.target.files?.[0] ?? null);

  const upload = async (e) => {
    e.preventDefault();
    if (!file) return setStatus("Choose a file first");

    setStatus("Uploading...");
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("dataset", "distribution"); // example metadata
      form.append("year", "2024");

      // get Firebase ID token
      const token = await (currentUser?.getIdToken?.() ?? getIdToken());

      const res = await fetch("/api/admin/upload", {
        method: "POST",
        headers: {
          // DO NOT set 'Content-Type' here when sending FormData!
          Authorization: `Bearer ${token}`,
        },
        body: form,
      });

      // Defensive: check content-type before parsing JSON
      const contentType = res.headers.get("content-type") || "";
      if (!res.ok) {
        // Try to read text for better debugging
        const text = await res.text();
        throw new Error(`Upload failed (${res.status}): ${text || res.statusText}`);
      }

      if (contentType.includes("application/json")) {
        const data = await res.json();
        setStatus(`Success: imported ${data.insertedCount} rows.`);
      } else {
        // Server returned something else (e.g., plain text)
        const text = await res.text();
        setStatus("Upload response: " + text);
      }
    } catch (err) {
      console.error("Upload error:", err);
      setStatus("Upload failed: " + (err.message || err.toString()));
    }
  };

  return (
    <div>
      <h3>Admin CSV Upload</h3>
      <form onSubmit={upload}>
        <input type="file" accept=".csv" onChange={handleFile} />
        <button type="submit" disabled={!file}>Upload</button>
      </form>
      <p>{status}</p>
    </div>
  );
}
